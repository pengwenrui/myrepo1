package com.pwr.test;

import com.pwr.dao.CarDao;
import com.pwr.domain.Car;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class main {
    public static void main(String [] args){
        test();
    }
    public static void test(){
        CarDao dao=new CarDao();
        Car c=new Car();
        dao.buy("kc",6,2);
//        ArrayList al =dao.getArr("hc",3);
//        for (int i=0;i<al.size();i++){
//            System.out.println(al.get(i));
//        }
//       ArrayList al=dao.show("hc");
//        for (int i=0;i<al.size();i++){
//            c=(Car) al.get(i);
//            System.out.println(c.toString());
//
//        }
    }

}
