package com.pwr.dao;

import com.pwr.domain.Car;
import com.pwr.utils.XmlUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class CarDao {

    public ArrayList<Car> show(String name) {
        try {
            Document document = XmlUtils.getDocument("src/car.xml");
            NodeList list = document.getElementsByTagName(name);
            ArrayList<Car> al = new ArrayList<Car>();
            for (int i = 0; i < list.getLength(); i++) {
                Element car_tag = (Element) list.item(i);
                Car car = new Car();
                car.setName(name);
                car.setId((car_tag.getAttribute("id")));
                car.setPrice(Double.parseDouble(car_tag.getElementsByTagName("price").item(0).getTextContent()));
                car.setCarry(Double.parseDouble(car_tag.getElementsByTagName("carry").item(0).getTextContent()));
                al.add(car);
            }
            return al;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    //返回一个ArrayList 集合
    public ArrayList getArr(String type, int id){
        ArrayList al=new ArrayList();
        try {

            Document document = XmlUtils.getDocument("src/car.xml");
           NodeList list=document.getElementsByTagName(type);
            for (int i = 0; i < list.getLength(); i++) {
                Element cat_type=(Element) list.item(i);
                //System.out.println(cat_type.getAttribute("id"));
                if(cat_type.getAttribute("id").equals(id+"")){
                    al.add(cat_type.getAttribute("id"));
                    al.add(cat_type.getElementsByTagName("name").item(0).getTextContent());
                   // System.out.println(cat_type.getElementsByTagName("name").item(0).getTextContent());
                    al.add(cat_type.getElementsByTagName("price").item(0).getTextContent());
                    al.add(cat_type.getElementsByTagName("carry").item(0).getTextContent());
                }
            }
            return al;
        }catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    public int buy(String type, int id,int num){
        try {
            int total=0;
            Document document = XmlUtils.getDocument("src/result.xml");
            ArrayList al=getArr(type,id);
            //得到后创建标签


            Element information = document.createElement("information");
            information.setAttribute("id",id+"");

            Element name = document.createElement("name");
            Element carry = document.createElement("carry");
            Element price = document.createElement("price");
            Element type2=document.createElement("type");
            Element sum=document.createElement("sum");
            name.setTextContent((String)al.get(0));
            carry.setTextContent((String)al.get(1));
            price.setTextContent((String)al.get(2));
            type2.setTextContent(type);
            total=Integer.parseInt(al.get(2).toString())*num;
            sum.setTextContent(total+"");

            information.appendChild(name);
            information.appendChild(carry);
            information.appendChild(price);
            information.appendChild(type2);
            information.appendChild(sum);

            document.getElementsByTagName("cars").item(0).appendChild(information);
            XmlUtils.write2Xml(document,"src/result.xml");
            return total;
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
