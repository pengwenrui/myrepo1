package com.pwr.UI;


import com.pwr.dao.CarDao;
import com.pwr.domain.Car;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.io.InputStreamReader;


public class Main {
    public static void main(String [] args){
        try {
            System.out.println("欢迎进入租车系统");
            System.out.println("请选择车型的编号(1.客车  2.货车  3.皮卡车)");
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    System.in));
            String select=br.readLine();
            if("1".equals(select)){
                String type="hc";
                CarDao dao=new CarDao();
                ArrayList al=dao.show(type);
                Car c=new Car();
                 for (int i=0;i<al.size();i++){
                  c=(Car) al.get(i);
                     System.out.println(c.toString());

            }
                System.out.println("请选择具体车型的编号:");
                int  id=(Integer.parseInt(br.readLine()));
                System.out.println("请输入租用天数:");
                int  num=(Integer.parseInt(br.readLine()));
                dao.buy(type,id,num);

            }
            else if("2".equals(select)){
                String type="kc";
                CarDao dao=new CarDao();
                ArrayList al=dao.show(type);
                Car c=new Car();
                for (int i=0;i<al.size();i++){
                    c=(Car) al.get(i);
                    System.out.println(c.toString());

                }
                System.out.println("请选择具体车型的编号:");
                int  id=(Integer.parseInt(br.readLine()));
                System.out.println("请输入租用天数:");
                int  num=(Integer.parseInt(br.readLine()));
                dao.buy(type,id,num);

            }else if("3".equals(select)){
                String type="pkc";
                CarDao dao=new CarDao();
                ArrayList al=dao.show(type);
                Car c=new Car();
                for (int i=0;i<al.size();i++){
                    c=(Car) al.get(i);
                    System.out.println(c.toString());

                }
                System.out.println("请选择具体车型的编号:");
                int  id=(Integer.parseInt(br.readLine()));
                System.out.println("请输入租用天数:");
                int  num=(Integer.parseInt(br.readLine()));
                int sum=dao.buy(type,id,num);
                System.out.println("sum="+sum);

            }
        System.out.println("success！");
        }
        catch (Exception e){
            e.printStackTrace();
            System.out.println("出错了");
        }
    }
}
